import React, { Component } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Image,
  FlatList,
  Alert
} from 'react-native';
import axios from 'axios'
import {datacore} from './coredata.json' 
class QkWeatherApp extends Component {
  state = {
    temp_city: '',
    cityname: '',
    data: datacore,

  }
  componentWillMount() {
    axios.get(`http://api.openweathermap.org/data/2.5/forecast/daily?q=bangkok&appid=927d09bc49dbee6aac7f5cb1df707542`)
      .then(res => this.setState({ data: res.data }))
  }
  search = () => {
    axios.get(`http://api.openweathermap.org/data/2.5/forecast/daily?q=${this.state.cityname}&appid=927d09bc49dbee6aac7f5cb1df707542`)
      .then(res =>
        this.setState({ data: res.data })
      )
  }
  gettoday(mili) {
    var d = new Date(mili)
    dd = d.getDay()
    mm = d.getMonth() + 1
    yy = d.getFullYear()
    var ans = '' + dd + '/' + mm + '/' + yy
    return ans
  }
  _renderItem = ({ item }) =>
    <View style={{ flexDirection: 'row', justifyContent: 'flex-start', backgroundColor: 'blue', alignItems: 'center' }}>
      <Text style={{ fontSize: 20, color: 'cyan' }}> {this.gettoday(1456456456)} </Text>
      <Text style={{ fontSize: 20, color: 'cyan' }}> {parseInt(item.temp.day)} </Text>
      <Image source={require('./img/rain.png')} style={{ height: 50, width: 50 }} />
      <View style={{ height: 5 }} />
    </View>
  render() {
    return (
      <View style={st.container}>
        <View style={st.header}>
          <TextInput
            style={st.textinput}
            placeholder={'City...'}
            autoCorrect={false}
            onChangeText={(text) => this.setState({ cityname: text })}
          />
          <TouchableOpacity
            style={st.button}
            onPress={() => this.search()}>
            <Text style={{ fontSize: 20, fontWeight: 'bold' }}> Search </Text>
          </TouchableOpacity>
        </View>
        <Text style={st.title} > {this.state.data.city.name} </Text>
        <Text style={st.date} > 27/07/2018 </Text>
        <View style={st.current}>
          <View style={st.itemincurrent}>
            <Image style={{ height: 100, width: 100 }} source={require('./img/rain.png')} />
            <Text style={st.status}> Light Rain </Text>
          </View>
          <View style={st.itemincurrent}>
            <Text style={st.temperate}> 24 </Text>
            <View style={st.buttonCF}>
              <TouchableOpacity>
                <Text style={{ fontSize: 20, color: 'white' }}>°F</Text>
              </TouchableOpacity>
              <TouchableOpacity>
                <Text style={{ fontSize: 20, color: 'white' }}>°C</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
        <FlatList
          data={this.state.data.list}
          renderItem={({ item }) => this._renderItem({ item })} />
      </View >
    );
  }
}

const st = StyleSheet.create({
  buttonCF: {
    flexDirection: 'row',
    height: 50,
    width: 100,
    alignItems: 'center',
    justifyContent: 'space-around'
  },
  status: {
    color: 'white',
    fontSize: 20,
  },
  temperate: {
    fontSize: 70,
    fontWeight: 'bold',
    color: 'white'
  },
  itemincurrent: {
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
  },

  flatitem: {

  },
  current: {
    flexDirection: 'row',

  },
  title: {
    fontSize: 50,
    fontWeight: 'bold',
    color: 'white'
  },
  date: {
    fontSize: 20,
    color: 'white',
  },
  container: {
    flex: 1,
    backgroundColor: 'rgb(56,54,74)',
    justifyContent: 'center',
    alignItems: 'center'
  },
  header: {
    height: 100,
    width: '85%',
    alignItems: 'center',
    justifyContent: 'space-around',
    flexDirection: 'row',
  },
  textinput: {
    height: 40,
    width: 200,
    borderRadius: 5,
    backgroundColor: 'white'
  },
  button: {
    height: 40,
    width: 100,
    borderRadius: 5,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center'
  }
})
export default QkWeatherApp;